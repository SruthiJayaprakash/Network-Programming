# socket-programming-java
Write a set of socket programs to perform the following: (Note: use UDP sockets for
implementation)
a) An Electronic Notice Board server program to display the contents pasted by the client programs.
b) An authentication server to authenticate the user to post and delete the news contents on to the
notice board.
c) Client program to post and delete the news contents using the above two servers.
